/*
 * Name: Andy Cook
 * Date: 09/11/2013
 * Program Desc: Program generates two random numbers, then tests user on answer to multiplication.
 * A different method is called to give a message depending on if their answer is correct.
 * 
 */
import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {

		// Create a Scanner
		Scanner input = new Scanner(System.in);

		// generate two random numbers in range [1-100]
		int maxNumber = 100;
		int minNumber = 1;
		int n1 = (int) (Math.random() * maxNumber) + minNumber;
		int n2 = (int) (Math.random() * maxNumber) + minNumber;
		int answer = n1 * n2;
		/*
		 * ask user n1 * n2 if correct call method printGoodComment else call
		 * printBadComment
		 */
		System.out.println("What is the value of: " + n1 + " * " + n2);
		int inputNumber = input.nextInt();
		if (inputNumber == answer) {
			printGoodComment();
		}
		else {
			printBadComment();
		}
	}

	public static void printGoodComment() {
		// Generate random number in range [0-3]
		int random = (int) (Math.random() * 4);
		switch (random) {
		case 0:
			System.out.println("good job");
			break;
		case 1:
			System.out.println("excellent");
			break;
		case 2:
			System.out.println("terrific");
			break;
		case 3:
			System.out.println("nice work");
			break;
		default:
			System.out.println("Incorrect random number generated.");
			break;
		}
	}

	public static void printBadComment() {
		// Generate random number in range [0-2]
		int random = (int) (Math.random() * 3);
		switch (random) {
		case 0:
			System.out.println("sorry, try next time");
			break;
		case 1:
			System.out.println("oops, you need more work");
			break;
		case 2:
			System.out.println("hmm, it is not correct");
			break;
		default:
			System.out.println("Incorrect random number generated.");
			break;
		}
	}
}
