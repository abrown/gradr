
//Debbie Bielski
//September 14, 2013
/*This program helps a student learn multiplication by generating 2 random numbers and asks the student to find the product.
 Depending if the answer is correct or incorrect, it generate either a good message or a "mean" message.*/

/*Key data structures used in this program:
 		-integer
 		-boolean*/

/*Key features used in this program:
 		-switch statements
 		-new methods
 */

import java.util.Scanner;

public class Assignment3 {
	public static void main(String[] arg) {

		int num1 = 0; // factor 1
		int num2 = 0; // factor 2
		int answer = 0; // correct answer

		// Create new scanner
		// Generate 2 random numbers to multiply
		num1 = (int) (Math.random() * 101);
		num2 = (int) (Math.random() * 101);

		// Generate question
		System.out.println("What is the value of " + num1 + " x " + num2 + "?");

		// Create new scanner
		Scanner input = new Scanner(System.in);
		int guess = input.nextInt();
		answer = (num1 * num2);
		
		//Invoke methods for good comments and "mean" comments based on user input
		if (guess == answer) {
			Assignment3.printGoodComment();
		} else
			Assignment3.printBadComment();
	}

	// method definition for "nice" random comments
	public static void printGoodComment() {
		if (true) {
			switch ((int) (Math.random() * 4)) {
			case 0:
				System.out.print("Good Job!");
				break;

			case 1:
				System.out.print("Excellent!");
				break;

			case 2:
				System.out.print("Terrific!");
				break;

			case 3:
				System.out.print("Nice Work!");
				break;
			}
		}
	}

	// method definition for "mean" random comment
	public static void printBadComment() {
		switch ((int) (Math.random() * 3)) {

		case 0:
			System.out.print("Sorry, try next time.");
			break;

		case 1:
			System.out.print("Oops, you need more work.");
			break;

		case 2:
			System.out.print("Hmm, it is not correct.");
			break;
		}
	}
}
//End Assignment3