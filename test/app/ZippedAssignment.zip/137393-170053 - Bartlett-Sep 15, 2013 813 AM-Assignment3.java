/*Sam Bartlett
 * 09/14/2013
 * 
 * Assignment3 
 * Math Test- demonstrate how to use methods by
 * randomly generating two numbers and asking user to add them, then call different methods
 * that display comments depending correct/incorrect answers and 
 * making a variety of responses using Math.random and switch
 */

import java.util.Scanner;

public class Assignment3 {

    public static void main(String[] args) {

        String exitVar = "y";
        Scanner input = new Scanner(System.in);

        System.out.println("Math Test");
        System.out.println("Test your math skills, answer the following:");

        while (exitVar.equalsIgnoreCase("y")) {

            int num1 = makeRand();
            int num2 = makeRand();
            int answer = num1 + num2;
            System.out.println("What is " + num1 + " plus " + num2 + "?");
            if (answer == input.nextInt()) {
                printGoodComment();
            } else {
                printBadComment();
            }
            System.out.println("Want to try again? Enter y for yes or n for no:");
            exitVar = input.next();
        }


    }

    public static void printGoodComment() {

        int rand = (int) (Math.random() * 4);
        switch (rand) {
            case 0:
                System.out.println("Good Job!");
                break;
            case 1:
                System.out.println("Excellent!");
                break;
            case 2:
                System.out.println("Terrific!");
                break;
            case 3:
                System.out.println("Nice Work!");
                break;
        }

    }

    public static void printBadComment() {
        int rand = (int) (Math.random() * 3);
        switch (rand) {
            case 0:
                System.out.println("Sorry, try next time.");
                break;
            case 1:
                System.out.println("Oops! You need more work!");
                break;
            case 2:
                System.out.println("Hmm, it is not correct...");
                break;
        }
    }

    public static int makeRand() {
        return (int) (Math.random() * ((100 - 1) + 1) + 1);
    }
}
