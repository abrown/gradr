 * @author Thu Nguyen 9/15/13
 * The Assignment 3 program is a math quiz generating two random numbers in a multiplication problem. 
 * If the user gets the multiplication problem correct, a good comment will result. If the user has an incorrect response, a bad comment results.
 *Key features of this program include using an if statement, invoking two dfferent methods and using switch statements.


import java.util.Scanner;
public class Assignment3 {
	public static void main(String[] args) {
		// Create a Scanner
		Scanner input = new Scanner(System.in);
		int userAnswer = input.nextInt();
		int value = (int) (Math.random () * 4);
		int random = (int)(Math.random() * 3);
		int n1 = 1+ (int)(Math.random() * 100);
		int n2 = 1+ (int)(Math.random() * 100);
		
		//Prompt user to answer "What is n1*n2?"
			System.out.println("What is" + n1 + "*" + n2 + "?");
			//input here		
			
	if (userAnswer == n1 * n2)
		{
			printGoodComment(value);
		}
	else 
		printBadComment(random);
	}	
			
		//Invoke goodComment method
	public static void printGoodComment(int x){
		
		int value = (int) (Math.random () * 4);
		//Grade user's answer and display result
		switch (value){
			case 1:
				System.out.println("Good job!");
				break;
			case 2:
				System.out.println("Excellent!");
				break;
			case 3:
				System.out.println("Terrific!");
				break;
			case 4:
				System.out.println("Nice Work!");
				break; 
	}
}
		//Invoke badComment method
	public static void printBadComment(int x){
		
		int random = (int) (Math.random () * 3);
		//Grade user's answer and display result
		switch (random){
			case 1:
				System.out.println("Sorry try next time!");
				break;
			case 2:
				System.out.println("Oops you need more work!");
				break;
			case 3:
				System.out.println("Hmm it is not correct!");
				break;
		}			
	}
	}