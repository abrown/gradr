/*
* AnnaBankston 
* Date:09152013 Assignment3
* The program below tests multiplication skills of the user using 10 questions generating random numbers from 1-100 and providing good and bad comments
*/
import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {
		// Set number of questions on test
			final int NUMBER_OF_QUESTIONS = 10;
			int count = 0;

	Scanner input = new Scanner(System.in);

		// Generate two random numbers between 1 and 100 to be multiplied by user
		while (count < NUMBER_OF_QUESTIONS) {
			int n1 = (int) (Math.random() * (100 - 1) + 1);
			int n2 = (int) (Math.random() * (100 - 1) + 1);

		// Prompt the user for the answer to n1*n2
			System.out.println("What is " + n1 + " x " + n2 + "? ");
			int answer = input.nextInt();

		// Display random comments if the answer is 'good' or 'bad'
		if (n1 * n2 == answer)  {
				printGoodComment(); }
		else {
				printBadComment();
	}
		count++; }
		
	}

	   // Switch statements to generate random good and bad comments based on the users answer above being correct or not
	public static void printGoodComment() {
		int GoodComment = (int) (Math.random() * (3 - 0) + 1);
		switch (GoodComment) {
		case 1:
			System.out.println("good job");
			break;
		case 2:
			System.out.println("excellent");
			break;
		case 3:
			System.out.println("terrific");
			break;
		case 4:
			System.out.println("nice work");
			break;
	}
	}

	public static void printBadComment() {
		int BadComment = (int) (Math.random() * (2 - 0) + 1);
		switch (BadComment) {
		case 1:
			System.out.println("sorry, try next time");
			break;
		case 2:
			System.out.println("oops, you need more work");
			break;
		case 3:
			System.out.println("hmm, it is not correct");
			break;
	}
	}
}