/* Assignment3
 * John Scarborough
 * 09.15.2013
 * 
 * Ask a math question and evaluate the answer.  
 */
//package assignments;

import java.util.Scanner;

public class Assignment3 {
	
	public static void main(String[]args) {
		//I thought it might be easier to grade if you didn't have to run the program over and over for each question.  
		int questionNumber = 1;
		String exitText = "Enter '0' to end the program.";
		System.out.println(exitText);
		
		int correct = 0;
		int feedBack = 0;
		
		do {
			//add a blank line for formatting
			System.out.println("");
			//every 5 questions repeat exit instructions
			if (questionNumber % 5 == 0){
				System.out.println(exitText);
			}
			System.out.println("Question "+questionNumber+":");
			//ask user question
			feedBack = askQuestion();
			switch (feedBack) {
				case 0:  //request to end question list
					break;
				case 2: //correct answer
					correct++;
				case 1: //wrong answer also do this if correct
					questionNumber++;
					break;
				
				
			}
		} while (feedBack != 0);
		
		
		questionNumber--;  //back steps the escape questions
		//add a blank line for formatting
		System.out.println("");
		System.out.println("--------------------");
		System.out.println("You answered "+correct+" out of "+questionNumber+" correct.");
		
	}
	
	public static int askQuestion() {
		//print question and get answer
		int correctAnswer = stateQuestion();
		
		//retrieve feed back
		Scanner input = new Scanner(System.in);
		int userAnswer = input.nextInt();
		
		//compare feedback to answer and return feedback
		int solved = 1;
		if (userAnswer == 0) {
			solved  = 0;  //this will indicate that we should stop the loop
		} else if (userAnswer == correctAnswer) {
			printGoodComment();	
			solved = 2;
		} else {
			printBadComment();
		}
		
		//Eclipse wanted me to close this input.  However, that caused the program to fail after one iteration of the input being used.
		//From the chapters, I believe every time this function ends the memory is dumped that was used for it.  This would also close the input.
		//input.close();
			
		return solved;
	}
	
	public static int stateQuestion() {
		//generate question
		int intOne = (int) (Math.random() * 100) + 1;
		int intTwo = (int) (Math.random() * 100) + 1;
		int answer = intOne * intTwo;
		
		//state question
		//The directions have us take the second integer to the 1nth power.  Since this doesn't alter the answer I have removed it.
		//In case this wasn't a typo on the instructions I've commented out the question with the second raised to the power of 1.  
		//This is the only line that would change as x^1 is always x.
		//System.out.println(intOne + " * " + intTwo + "^1");
		System.out.println(intOne + " * " + intTwo); 
		//uncomment next line to make testing easier
		//System.out.println(answer);
		return answer;
	}
	
	public static void printGoodComment() {
		//print a random good statement
		switch((int) (Math.random() * 4)+1) {
			case 1: 
				System.out.println("good job");
				break;
			case 2: 
				System.out.println("excellent");
				break;
			case 3: 
				System.out.println("terrific");
				break;
			case 4: 
				System.out.println("nice work");
				break;
		}
	}
	
	public static void printBadComment() {
		//print a random bad statement
		switch((int) (Math.random() * 3)+1) {
			case 1:
				System.out.println("sorry, try next time");
				break;
			case 2:
				System.out.println("oops, you need more work");
				break;
			case 3:
				System.out.println("hmm, it is not correct");
				break;
		}
	}


}
