



/*Whitney Noel
* Assignment 3
* Sept 11, 2013
* online exam w/comments
 */

import java.util.Scanner;

public class assignment3 {

	public static void main(String[] args) {
	
	Scanner input = new Scanner(System.in);
	// create 2 random numbers between 1 and 100
	int number1 = (int)(Math.random() * 101);
	int number2 = (int)(Math.random() * 101);
    int product = -1;
   
      		
	//read numbers and enter response
			System.out.print("What is the product of " + number1 + " and "  + number2 + "?\n" + 
					"Enter the product here: ");
			product = input.nextInt();	
			
	//evaluate product as either "good"  or "bad"
		
			if (product == number1 * number2)   
				printGoodComment();
			else
				printBadComment();
				
	}
	//goodComment method
			public static void printGoodComment(){
				int num;
				num = (int)(Math.random() * 4);
				switch (num) {
				case 0:
					System.out.print("Good job!");
					break;
				case 1: 
					System.out.print("Excellent!");
					break;
				case 2:
					System.out.print("Terrific!");
					break;
				case 3: 
					System.out.print("Nice work!");
					break;
	}
	}	
	
					
		//generate badComment method
				public static void printBadComment() {
					int num;
					num = (int)(Math.random() * 3);
					switch (num) {
					case 0:
						System.out.print("Sorry, try next time.");
						break;
					case 1: 
						System.out.print("Oops, you need more work.");
						break;
						
					case 2:
						System.out.print("Hmm, it is not correct.");
						break;
					
	}
	}								
	}
	
	
	
	